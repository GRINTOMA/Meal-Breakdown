export class food{
    name: string;
    price: string;
    calories: string;
}
