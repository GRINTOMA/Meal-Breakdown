export class grintoma{
    sid: number;
    sname: string;
    slogin: string;
    scampus: string;
    stitle: string;
}

